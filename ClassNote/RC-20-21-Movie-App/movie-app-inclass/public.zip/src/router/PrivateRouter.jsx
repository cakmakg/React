import React from 'react'

const PrivateRouter = () => {
  return (
    <div>PrivateRouter</div>
  )
}

export default PrivateRouter