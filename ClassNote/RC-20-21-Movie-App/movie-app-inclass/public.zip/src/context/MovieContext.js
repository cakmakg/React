import React from 'react'

const MovieContext = () => {
  return (
    <div>MovieContext</div>
  )
}

export default MovieContext